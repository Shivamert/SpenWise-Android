package com.spendwise.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "budgets")
data class BudgetEntity(
    @PrimaryKey
    val key: String = "monthly_budget",
    val amountMinor: Long = 0L,
    val warningThreshold: Int = 80
)