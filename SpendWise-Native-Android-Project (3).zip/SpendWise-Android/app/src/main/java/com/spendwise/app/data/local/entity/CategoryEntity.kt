package com.spendwise.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val icon: String,
    val colorHex: String,
    val isCustom: Boolean = false,
    val sortOrder: Int = 0
)