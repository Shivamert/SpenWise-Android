package com.spendwise.app.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "transactions",
    indices = [
        Index("date"),
        Index("categoryId")
    ]
)
data class TransactionEntity(
    @PrimaryKey
    val id: String,
    val amountMinor: Long,
    val categoryId: String,
    val date: String,
    val time: String? = null,
    val note: String? = null,
    val merchant: String? = null,
    val paymentMethod: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)