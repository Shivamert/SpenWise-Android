package com.spendwise.app

import android.app.Application

class SpendWiseApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}