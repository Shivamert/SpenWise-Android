package com.spendwise.app.ui.theme

import androidx.compose.ui.graphics.Color

val Emerald80 = Color(0xFF6EE7B7)
val Emerald40 = Color(0xFF059669)
val Emerald20 = Color(0xFF064E3B)

val Cyan80 = Color(0xFF67E8F9)
val Cyan40 = Color(0xFF0891B2)

val Amber80 = Color(0xFFFDE68A)
val Amber40 = Color(0xFFD97706)

val DarkBackground = Color(0xFF0D0F12)
val DarkSurface = Color(0xFF161A20)
val DarkSurfaceVariant = Color(0xFF222831)
val DarkOnSurface = Color(0xFFF3F4F6)
val DarkOutline = Color(0xFF374151)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnSurface = Color(0xFF0F172A)
val LightOutline = Color(0xFFE2E8F0)

val ExpenseRed = Color(0xFFEF4444)
val WarningYellow = Color(0xFFF59E0B)
val SafeGreen = Color(0xFF10B981)