package com.spendwise.app.data.local.dao

import androidx.room.*
import com.spendwise.app.data.local.entity.BudgetEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BudgetDao {
    @Query("SELECT * FROM budgets WHERE `key` = :key")
    fun getBudget(key: String): Flow<BudgetEntity?>

    @Query("SELECT * FROM budgets")
    fun getAllBudgets(): Flow<List<BudgetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setBudget(budget: BudgetEntity)

    @Query("DELETE FROM budgets WHERE `key` = :key")
    suspend fun deleteBudget(key: String)
}