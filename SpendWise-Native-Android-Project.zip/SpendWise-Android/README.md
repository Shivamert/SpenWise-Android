# SpendWise - Native Android Personal Expense Tracker

Built with Kotlin, Jetpack Compose, Material 3, and Room local database.

## Quick Start
1. Open this directory in **Android Studio Hedgehog / Iguana / Jellyfish** or newer.
2. Allow Gradle sync to complete.
3. Plug in your Android Phone with USB Debugging enabled, or start an Android Virtual Device (AVD).
4. Click **Run > Run 'app'** (Shift + F10).

## Building Release APK
```bash
./gradlew assembleRelease
```
APK will be located at:
`app/build/outputs/apk/release/app-release-unsigned.apk`
