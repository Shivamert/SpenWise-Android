package com.spendwise.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.spendwise.app.data.local.SpendWiseDatabase
import com.spendwise.app.data.repository.ExpenseRepository
import com.spendwise.app.ui.SpendWiseApp
import com.spendwise.app.ui.theme.SpendWiseTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Room local SQLite database (100% offline & private)
        val database = SpendWiseDatabase.getDatabase(this, CoroutineScope(Dispatchers.IO))
        val repository = ExpenseRepository(
            database.transactionDao(),
            database.categoryDao(),
            database.budgetDao()
        )

        setContent {
            SpendWiseTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SpendWiseApp(repository = repository)
                }
            }
        }
    }
}