package com.spendwise.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.spendwise.app.data.local.dao.BudgetDao
import com.spendwise.app.data.local.dao.CategoryDao
import com.spendwise.app.data.local.dao.TransactionDao
import com.spendwise.app.data.local.entity.BudgetEntity
import com.spendwise.app.data.local.entity.CategoryEntity
import com.spendwise.app.data.local.entity.TransactionEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        TransactionEntity::class,
        CategoryEntity::class,
        BudgetEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SpendWiseDatabase : RoomDatabase() {

    abstract fun transactionDao(): TransactionDao
    abstract fun categoryDao(): CategoryDao
    abstract fun budgetDao(): BudgetDao

    companion object {
        @Volatile
        private var INSTANCE: SpendWiseDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): SpendWiseDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SpendWiseDatabase::class.java,
                    "spendwise_database"
                )
                .addCallback(SpendWiseDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class SpendWiseDatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialCategories(database.categoryDao())
                    }
                }
            }

            suspend fun populateInitialCategories(categoryDao: CategoryDao) {
                val defaultCategories = listOf(
                    CategoryEntity("cat_food", "Food & Dining", "Utensils", "#F97316", false, 1),
                    CategoryEntity("cat_groceries", "Groceries", "ShoppingBag", "#10B981", false, 2),
                    CategoryEntity("cat_transport", "Transport", "Car", "#06B6D4", false, 3),
                    CategoryEntity("cat_shopping", "Shopping", "Gift", "#EC4899", false, 4),
                    CategoryEntity("cat_bills", "Bills & Utilities", "Zap", "#EAB308", false, 5),
                    CategoryEntity("cat_education", "Education", "GraduationCap", "#8B5CF6", false, 6),
                    CategoryEntity("cat_health", "Health", "Activity", "#EF4444", false, 7),
                    CategoryEntity("cat_entertainment", "Entertainment", "Film", "#6366F1", false, 8),
                    CategoryEntity("cat_housing", "Housing", "Home", "#14B8A6", false, 9),
                    CategoryEntity("cat_personal", "Personal Care", "Smile", "#F43F5E", false, 10),
                    CategoryEntity("cat_travel", "Travel", "Plane", "#3B82F6", false, 11),
                    CategoryEntity("cat_other", "Other", "MoreHorizontal", "#64748B", false, 12)
                )
                categoryDao.insertDefaultCategories(defaultCategories)
            }
        }
    }
}