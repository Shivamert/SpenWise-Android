package com.spendwise.app.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * TransactionEntity stores expenses with exact integer minor units (paise/cents)
 * to avoid floating point calculation errors in financial totals.
 */
@Entity(
    tableName = "transactions",
    indices = [
        Index("date"),
        Index("categoryId")
    ]
)
data class TransactionEntity(
    @PrimaryKey
    val id: String,
    val amountMinor: Long, // Integer minor units (e.g. 10050 for ₹100.50)
    val categoryId: String,
    val date: String, // ISO-8601 YYYY-MM-DD
    val time: String? = null, // HH:mm
    val note: String? = null,
    val merchant: String? = null,
    val paymentMethod: String? = null, // "cash", "upi", "credit_card", etc.
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)