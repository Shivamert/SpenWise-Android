package com.spendwise.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

data class CategorySlice(
    val name: String,
    val amountMinor: Long,
    val color: Color,
    val percentage: Float
)

@Composable
fun MonthlySpendBarChart(
    dailyTotals: List<Long>,
    modifier: Modifier = Modifier,
    barColor: Color = MaterialTheme.colorScheme.primary
) {
    val maxVal = dailyTotals.maxOrNull()?.coerceAtLeast(1L) ?: 1L

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(140.dp)
            .padding(vertical = 8.dp)
    ) {
        val count = dailyTotals.size
        if (count == 0) return@Canvas

        val spacing = size.width / count
        val barWidth = (spacing * 0.6f).coerceAtLeast(4f)

        dailyTotals.forEachIndexed { index, total ->
            val barHeight = (total.toFloat() / maxVal.toFloat()) * size.height
            val x = index * spacing + (spacing - barWidth) / 2
            val y = size.height - barHeight

            drawRoundRect(
                color = if (total > 0) barColor else Color.Gray.copy(alpha = 0.2f),
                topLeft = Offset(x, y),
                size = Size(barWidth, barHeight.coerceAtLeast(2f)),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
            )
        }
    }
}

@Composable
fun CategoryDonutChart(
    slices: List<CategorySlice>,
    modifier: Modifier = Modifier,
    centerText: String = ""
) {
    Box(
        modifier = modifier.size(160.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            var startAngle = -90f
            val strokeWidth = 24.dp.toPx()

            if (slices.isEmpty()) {
                drawCircle(
                    color = Color.Gray.copy(alpha = 0.2f),
                    style = Stroke(width = strokeWidth)
                )
            } else {
                slices.forEach { slice ->
                    val sweepAngle = slice.percentage * 360f
                    drawArc(
                        color = slice.color,
                        startAngle = startAngle,
                        sweepAngle = sweepAngle,
                        useCenter = false,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                    startAngle += sweepAngle
                }
            }
        }
        if (centerText.isNotEmpty()) {
            Text(
                text = centerText,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}